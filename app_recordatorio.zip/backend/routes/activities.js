// Activities routes placeholder
