// Activity model placeholder
