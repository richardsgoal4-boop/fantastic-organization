// User model placeholder
