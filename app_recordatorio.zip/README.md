# Proyecto App Recordatorio

Estructura base generada.